/* ========================================
   CARROSSEL DE LIVROS CONTÍNUO (ROLLING)
   O Alfarrábio - Seção Livros
   ======================================== */

const API_CONFIG = {
  baseUrl: '/backend/index.php/api',
  itemsLimit: 10 // Limite de 10 itens conforme solicitado
};

/**
 * Inicializa ao carregar a página
 */
document.addEventListener('DOMContentLoaded', () => {
  console.log('🚀 Inicializando carrossel contínuo...');
  carregarProdutos();
});

/**
 * Busca produtos do banco
 */
async function carregarProdutos() {
  try {
    const response = await fetch(`${API_CONFIG.baseUrl}/item?por_pagina=${API_CONFIG.itemsLimit}`);
    if (!response.ok) throw new Error(`Erro HTTP: ${response.status}`);

    const json = await response.json();

    if (json.status === 'success' && json.data && json.data.length > 0) {
      // Força limite de 10 itens no frontend
      const itensLimitados = json.data.slice(0, 10);
      renderizarCarrosselContinuo(itensLimitados);
    } else {
      document.getElementById('carouselTrack').innerHTML = '<div class="empty-message"><h3>Nenhum livro disponível</h3></div>';
    }
  } catch (error) {
    console.error('❌ Erro ao carregar produtos:', error);
  }
}

/**
 * Renderiza os cards e duplica-os para criar o efeito de "esteira" infinita
 */
function renderizarCarrosselContinuo(produtos) {
  const track = document.getElementById('carouselTrack');
  if (!track) return;

  track.innerHTML = '';

  // Criamos o conjunto original de cards
  const fragmentoOriginal = document.createDocumentFragment();
  produtos.forEach(p => fragmentoOriginal.appendChild(criarCard(p)));

  // Para o efeito de rolagem contínua sem saltos (CSS animation translate -50%), 
  // precisamos de EXATAMENTE duas cópias idênticas lado a lado.
  const copia1 = fragmentoOriginal.cloneNode(true);
  const copia2 = fragmentoOriginal.cloneNode(true);

  track.appendChild(copia1);
  track.appendChild(copia2);

  console.log(`✅ Carrossel renderizado com ${produtos.length * 2} cards (duplicado para loop).`);
}

/**
 * Cria o elemento HTML do card (mantendo a padronização de tamanho)
 */
function criarCard(produto) {
  const preco = parseFloat(produto.preco || 0);
  const precoFormatado = preco.toFixed(2).replace('.', ',');

  const card = document.createElement('div');
  card.className = 'book-card-modern';

  const badge = produto.destaque ? '<div class="book-badge">Destaque</div>' : '';

  card.innerHTML = `
    ${badge}
    <div class="book-image-wrapper">
      <img src="${produto.caminho_imagem || '/img/sem-imagem.png'}" 
           alt="${produto.titulo}"
           onerror="this.src='/img/sem-imagem.png'">
    </div>
    <div class="book-info">
      <h3 class="book-title">${produto.titulo}</h3>
      ${produto.autores ? `<span class="book-author">${produto.autores}</span>` : ''}
      <div class="book-price-wrapper">
        <span class="book-price">R$ ${precoFormatado}</span>
        <button class="book-btn" onclick="verDetalhes(${produto.id_item})">Ver mais</button>
      </div>
    </div>
  `;
  return card;
}

function verDetalhes(idItem) {
  window.location.href = `produtos.html?id=${idItem}`;
}